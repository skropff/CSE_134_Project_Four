# pintos-threads
Extend pintos timer functionality to not use busy wait.
